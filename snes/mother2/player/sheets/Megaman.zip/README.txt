SpriteSomething-collections
Earthbound
Player

SpriteSomething: http://artheau.github.io/SpriteSomething

Sprite: Megaman
Artist: Artheau
